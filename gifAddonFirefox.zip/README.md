"# GIFDescriptorExtension - An extension that helps create alt text for GIF images. " 
